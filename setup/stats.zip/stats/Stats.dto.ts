export interface TemperaturesDTO {
    [location: string]: number;
}
